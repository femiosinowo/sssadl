﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SSADL.CMS;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using System.Configuration;

public partial class admin_reports_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        reportID = Request.QueryString["deleteReportID"].ToString();
        string deleteSQL = "Delete from ReportSchedule where ID=" + Request.QueryString["deleteReportID"].ToString();
        DataBase.executeCommand(deleteSQL);

    }





    public string reportID { get; set; }
   
}