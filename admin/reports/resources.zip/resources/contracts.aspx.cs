﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SSADL.CMS;
using System.Data;
using System.Collections;
using System.Data.SqlClient;
using System.Configuration;
using System.Xml;

public partial class admin_reports_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            customDatSDDisplay = " style='display:none' ";
            //dtAllResouces = getAllResouces();
            //ListResources.DataSource = dtAllResouces;
            //ListResources.DataBind();
            if (Request.QueryString["reportid"] != null)
            {
                defaultResourceLoad.Visible = false;
                reportID = Request.QueryString["reportid"].ToString();
                getExistingData(reportID);
                RunReport.Visible = false;
                SaveReport.Visible = true;

            }
            else
            {
                DateRange.Items.FindByValue("This Fiscal Year").Selected = true;
                CompareDataAgainst.Items.FindByValue("Prior FY").Selected = true;
            }
        }
    }

    private void getExistingData(string reportID)
    {
         DataTableReader dtr = DataBase.dbDataTable("Select * from report where ID='" + reportID + "'").CreateDataReader();
         if (dtr.HasRows)
         {
             dtr.Read();
             string xmldata = dtr["ReportXMLData"].ToString();
             XmlDocument XMLDoc = new XmlDocument();
             XMLDoc.LoadXml(xmldata);


             string reportType = commonfunctions.getFieldValue(XMLDoc, "reportType");
             string compare = commonfunctions.getFieldValue(XMLDoc, "compare");
               Resources = commonfunctions.getFieldValue(XMLDoc, "Resources");
               ProcurementMethod = commonfunctions.getFieldValue(XMLDoc, "ProcurementMethod");
               ResourceTypeTaxonomy = commonfunctions.getFieldValue(XMLDoc, "ResourceTypeTaxonomy");
             string DateRangeTxt = commonfunctions.getFieldValue(XMLDoc, "DateRange");
             string StartDateTxt = commonfunctions.getFieldValue(XMLDoc, "StartDate");
             string EndDateTxt = commonfunctions.getFieldValue(XMLDoc, "EndDate");
             string CompareDataAgainstTxt = commonfunctions.getFieldValue(XMLDoc, "CompareDataAgainst");

             ReportTypeDD.Items.FindByValue(reportType).Selected = true;
             CompareDD.Items.FindByValue(compare).Selected = true;
             compareDisplay = compare;
            // getCompareDisplayData(compare);
            // Response.Write("<script>loadCompareResults('" + compare + "');</script>");


             selectedCompareData = compare;            
             switch (compare)
             {
                 case "Resources":

                     break;

                 case "Resources by Procurement Method":
                     compareEditDiv.Visible = true;
                     SelectedcompareID = ProcurementMethod;
                     break;
                 case "Resources by Type":
                     compareEditDiv.Visible = true;
                     SelectedcompareID = ResourceTypeTaxonomy;
                     break;

             }

            
                 
             DateRange.Items.FindByValue(DateRangeTxt).Selected = true;
             if (DateRangeTxt == "Custom Dates")
             {
                 StartDate.Text = StartDateTxt;
                 EndDate.Text = EndDateTxt;
                 customDatSDDisplay = " style='display:block' ";
             }
             else
             {
                 customDatSDDisplay = " style='display:none' ";
             }

             CompareDataAgainst.Items.FindByValue(CompareDataAgainstTxt).Selected = true;

             EditPanel.Visible = true;

         }

    }

    private void getCompareDisplayData(string compare)
    {
        ResourceCat = compare;
        selectedCompareData = compare;
        compareEditDiv.Visible = true;
        switch (compare)
        {
            case "Resources":
               
                break;

            case "Resources by Procurement Method":
                
                break;


            case "Resources by Type":
                
                break;




        }
    }



    //public DataTable dtAllResouces  ;
    //private DataTable getAllResouces()
    //{
    //    return DataBase.dbDataTable("Select * from Resources order by ResourceName");

    //}

    protected void RunReport_Click(object sender, EventArgs e)
    {
        string xmlData = getXML();

        string sql = " INSERT INTO [dbo].[Report]([Name],[CreatedbyPIN],[CreateDate],[LastModifiedDate],[LastRunDate],[ReportExecutionFile],[ReportSQLStatement],[ReportXMLData], ReportType) ";
        sql += "  VALUES(@Name,@CreatedbyPIN ,GETDATE() ,GETDATE() ,GETDATE(),@ReportExecutionFile ,@ReportSQLStatement ,@ReportXMLData, 'Ad Hoc Contract Report' ) ";

        SqlCommand sqlcmd = new SqlCommand(sql);
        sqlcmd.Parameters.AddWithValue("@Name", "Ad Hoc Help Report");
        sqlcmd.Parameters.AddWithValue("@CreatedbyPIN", loginSSA.myPIN);
        sqlcmd.Parameters.AddWithValue("@ReportExecutionFile", "");
        sqlcmd.Parameters.AddWithValue("@ReportSQLStatement", "");
        sqlcmd.Parameters.AddWithValue("@ReportXMLData", xmlData);
        string reportIDD = DataBase.executeCommandWithParametersReturnIDENTITY(sqlcmd);
         Response.Redirect("/admin/reports/resources/contractsResults.aspx?reportid=" + reportIDD + "#sb=1");
         //Response.Write(Request.Form);
    }



    protected void SaveReport_Click(object sender, EventArgs e)
    {
        string XMLData = getXML();
        string reportID = Request.QueryString["reportid"].ToString();
        string sql = "UPDATE [dbo].[Report] SET [LastModifiedDate] = GETDATE()   ,[ReportXMLData] = @ReportXMLData  ";
        sql += " WHERE ID=" + reportID;
       // Response.Write(sql);
        SqlCommand sqlcmd = new SqlCommand(sql);
        sqlcmd.Parameters.AddWithValue("@ReportXMLData", XMLData);
        DataBase.executeCommandWithParameters(sqlcmd);
        Response.Redirect("/admin/reports/resources/contractsResults.aspx?reportid=" + reportID + "#sb=1");

    }


    private string getXML()
    {
        string xmlData = "<root>";

        string reportType = ReportTypeDD.SelectedValue;
        xmlData += "<reportType>" + reportType + "</reportType>";

        string compare = CompareDD.SelectedValue;
        xmlData += "<compare>" + compare + "</compare>";

      //  Response.Write(getResouces());

        string Resources = getResources();
        xmlData += "<Resources>" + Resources + "</Resources>";


        string ProcurementMethod = getValueFromForm("ProcurementMethod");
        xmlData += "<ProcurementMethod>" + ProcurementMethod + "</ProcurementMethod>";


        string ResourceTypeTaxonomy = getValueFromForm("ResourceTypeTaxonomy");
        xmlData += "<ResourceTypeTaxonomy>" + ResourceTypeTaxonomy + "</ResourceTypeTaxonomy>";


        string DateRangeTxt = DateRange.SelectedValue;
        xmlData += "<DateRange>" + DateRangeTxt + "</DateRange>";

       // string StartDate = getValueFromForm("ctl00_mainContentCP_StartDate");
        xmlData += "<StartDate>" + StartDate.Text + "</StartDate>";


       // string EndDate = getValueFromForm("ctl00_mainContentCP_EndDate");
        xmlData += "<EndDate>" + EndDate.Text + "</EndDate>";



        string CompareDataAgainstTxt = CompareDataAgainst.SelectedValue;
        xmlData += "<CompareDataAgainst>" + CompareDataAgainstTxt + "</CompareDataAgainst>";
        


        xmlData += "</root>";

        return xmlData;

    }

    private string getValueFromForm(string whatField)
    {
        try
        {
            return Request.Form[whatField].ToString();
        }
        catch
        {

            return "";
        }
    }

    private string getResources()
    {

        string AllSelectedResourceID = string.Empty;
        try
        {
            string[] ListResourcesDD = this.Request.Form.GetValues("ListResourcesDD");
            foreach (string resourceID in ListResourcesDD)
            {

                AllSelectedResourceID += resourceID + ",";
            }
        }
        catch { }

        return AllSelectedResourceID.TrimEnd(',');
    }





    public string reportID { get; set; }

    public string compareDisplay { get; set; }

    public string Resources { get; set; }

    public string ResourceCat { get; set; }

    public string selectedCompareData { get; set; }

    public string SelectedcompareID { get; set; }

    public string customDatSDDisplay { get; set; }

    public string ProcurementMethod { get; set; }

    public string ResourceTypeTaxonomy { get; set; }
}