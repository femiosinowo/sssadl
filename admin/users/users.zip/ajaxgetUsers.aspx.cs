﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using SSADL.CMS;
using System.Net;
using System.Xml;

public partial class admin_users_ajaxgetUsers : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string pin = Request.QueryString["pin"].ToString();
        Dictionary<string, string> UsersDetails = loginSSA.GetUsersDetails(pin);

        Userfirstname = UsersDetails["LastName"];
        Userlastname = UsersDetails["FirstName"];
        UserServer = "myserver"; // UsersDetails["LastName"];
        UserDomain = "mydomain";  //UsersDetails["LastName"];



        fullname = UsersDetails["LastName"] + " " + UsersDetails["FirstName"];
        userTitle = UsersDetails["Title"];
        userComponent = UsersDetails["UPN"];
        userofficecode = UsersDetails["OfficeCode"];
        useremail = UsersDetails["Email"];
        userphone = UsersDetails["Telephone"];
    }

       public static Dictionary<string, string> GetUsersDetails(string PIN , string EMAIL="")
        {
            string coreEmailLink = "";
            string coreIVFLink ="";
            string coreOLVLink ="";
              if(commonfunctions.Environment=="DEV"){
               coreEmailLink = "http://coreemailval.sspf.ssa.gov/emailcore/EmailCoreService";
               coreIVFLink ="http://coreivfval.sspf.ssa.gov/services/IVFCoreService";
               coreOLVLink ="http://coreolval.sspf.ssa.gov/olcore/OfficeLookupCoreService";
        } 
        if(commonfunctions.Environment=="PROD"){
               coreEmailLink = "http://coreemail.sspf.ssa.gov/emailcore/EmailCoreService";
               coreIVFLink ="http://coreivf.sspf.ssa.gov/services/IVFCoreService";
               coreOLVLink ="http://coreol.sspf.ssa.gov/olcore/OfficeLookupCoreService";
        } 
            


             string CorePIN = "";
              Dictionary<string, string> UserDetails = new Dictionary<string, string>();
             string url = "";
            string urlgetPIN = "";
            //string sql = "SELECT * , CONCAT(LTRIM(RTRIM(FirstName)) , ' ', LTRIM(RTRIM(LastName))) as Name FROM [AccurintUsers] where PIN='" + PIN + "' ";
           if(PIN != "" ){
             urlgetPIN =coreEmailLink+ "?REQTYPE=GETALL&PIN=" + PIN;
           } else if(PIN =="" && EMAIL != "" ){
                //lets get pin from here                
                 urlgetPIN = coreEmailLink +"?REQTYPE=GETPIN&EMAIL=" + EMAIL;
           }
                     WebRequest requestEMAIL = WebRequest.Create(urlgetPIN);
            WebResponse responseEMAIL = requestEMAIL.GetResponse();

            XmlDocument xmlDocEMAIL = new XmlDocument();
            xmlDocEMAIL.Load(responseEMAIL.GetResponseStream());

              CorePIN = commonfunctions.getFieldValue(xmlDocEMAIL, "pin", "/service");

                
           
            if(CorePIN !=""){
             url = coreEmailLink + "?REQTYPE=GETALL&PIN=" + CorePIN;
            WebRequest request = WebRequest.Create(url);
            WebResponse response = request.GetResponse();

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(response.GetResponseStream());

            string displayName = commonfunctions.getFieldValue(xmlDoc, "displayName", "/service");
            string email = commonfunctions.getFieldValue(xmlDoc, "email", "/service");
            string office = commonfunctions.getFieldValue(xmlDoc, "office", "/service");
            string title = commonfunctions.getFieldValue(xmlDoc, "title", "/service");
            string telephone = commonfunctions.getFieldValue(xmlDoc, "telephone", "/service");
           
            string UPN = commonfunctions.getFieldValue(xmlDoc, "UPN", "/service");
             string PINN = commonfunctions.getFieldValue(xmlDoc, "pin", "/service");
          


            string urlD = coreIVFLink+"?PIN=" + CorePIN + "&Application=Test";
            WebRequest requestD = WebRequest.Create(urlD);
            WebResponse responseD = requestD.GetResponse();

            XmlDocument xmlDocD = new XmlDocument();
            xmlDocD.Load(responseD.GetResponseStream());
            string ocd = commonfunctions.getFieldValue(xmlDocD, "ocd", "/service/data");
            string department = commonfunctions.getFieldValue(xmlDocD, "dept", "/service/data");
                      string firstName = commonfunctions.getFieldValue(xmlDocD, "fnm", "/service/data");
            string lastName = commonfunctions.getFieldValue(xmlDocD, "lnm", "/service/data");

            string urlDDS = coreOLVLink+ "?OFFICECODEA=" + ocd + "&QUERYTYPE=1&APPLICATION=VALTEST";
            WebRequest requestDDS = WebRequest.Create(urlDDS);
            WebResponse responseDDS = requestDDS.GetResponse();

            XmlDocument xmlDocDDS = new XmlDocument();
            xmlDocDDS.Load(responseDDS.GetResponseStream());
            string dj9OfcTypeTxt = commonfunctions.getFieldValue(xmlDocDDS, "dj9OfcTypeTxt", "/service");  ///If this is DDS then the user is a DDS member



            string[] Names = displayName.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);

            UserDetails.Add("DisplayName", displayName);
            UserDetails.Add("Email", email);
            UserDetails.Add("OfficeCode", office);
            UserDetails.Add("Title", title);
            UserDetails.Add("Telephone", telephone);
            UserDetails.Add("Department", department);
            UserDetails.Add("UPN", UPN);
            UserDetails.Add("DDS", dj9OfcTypeTxt);
            UserDetails.Add("LastName", Names[0]);
            UserDetails.Add("FirstName", Names[1]);
            UserDetails.Add("Server", loginSSA.getMYIP());
            UserDetails.Add("Domain", "Domain");
             UserDetails.Add("PIN", PINN);
             UserDetails.Add("Component", department);

   

            }

            return UserDetails;

        }
    public static Dictionary<string, string> GetUsersDetails1(string PIN)
    {

        //string sql = "SELECT * , CONCAT(LTRIM(RTRIM(FirstName)) , ' ', LTRIM(RTRIM(LastName))) as Name FROM [AccurintUsers] where PIN='" + PIN + "' ";
        string url = "http://coreemailval.sspf.ssa.gov/emailcore/EmailCoreService?REQTYPE=GETALL&PIN=" + PIN;
        WebRequest request = WebRequest.Create(url);
        WebResponse response = request.GetResponse();

        XmlDocument xmlDoc = new XmlDocument();
        xmlDoc.Load(response.GetResponseStream());

        string displayName = commonfunctions.getFieldValue(xmlDoc, "displayName", "/service");
        string email = commonfunctions.getFieldValue(xmlDoc, "email", "/service");
        string office = commonfunctions.getFieldValue(xmlDoc, "office", "/service");
        string title = commonfunctions.getFieldValue(xmlDoc, "title", "/service");
        string telephone = commonfunctions.getFieldValue(xmlDoc, "telephone", "/service");
        string department = commonfunctions.getFieldValue(xmlDoc, "department", "/service");
        string UPN = commonfunctions.getFieldValue(xmlDoc, "UPN", "/service");

       


        string urlD = "http://coreivfval.sspf.ssa.gov/services/IVFCoreService?PIN=" + PIN + "&Application=Test";
        WebRequest requestD = WebRequest.Create(urlD);
        WebResponse responseD = requestD.GetResponse();

        XmlDocument xmlDocD = new XmlDocument();
        xmlDocD.Load(responseD.GetResponseStream());
        string ocd = commonfunctions.getFieldValue(xmlDocD, "ocd", "/service/data");



        string urlDDS = "http://coreolval.sspf.ssa.gov/olcore/OfficeLookupCoreService?OFFICECODEA=" + ocd + "&QUERYTYPE=1&APPLICATION=VALTEST";
        WebRequest requestDDS = WebRequest.Create(urlDDS);
        WebResponse responseDDS = requestDDS.GetResponse();

        XmlDocument xmlDocDDS = new XmlDocument();
        xmlDocDDS.Load(responseDDS.GetResponseStream());
        string dj9OfcTypeTxt = commonfunctions.getFieldValue(xmlDocDDS, "dj9OfcTypeTxt", "/service");  ///If this is DDS then the user is a DDS member



        string[] Names = displayName.Split(new string[] { "," }, StringSplitOptions.RemoveEmptyEntries);


        Dictionary<string, string> UserDetails = new Dictionary<string, string>();

        UserDetails.Add("DisplayName", displayName);
        UserDetails.Add("Email", email);
        UserDetails.Add("OfficeCode", office);
        UserDetails.Add("Title", title);
        UserDetails.Add("Telephone", telephone);
        UserDetails.Add("Department", department);
        UserDetails.Add("UPN", UPN);
        UserDetails.Add("DDS", dj9OfcTypeTxt);
        UserDetails.Add("LastName", Names[0]);
        UserDetails.Add("FirstName", Names[1]);
        //UserDetails.Add("", "");
        //UserDetails.Add("", "");
        //UserDetails.Add("", "");
        //UserDetails.Add("", "");
        //try
        //{
        //    DataTableReader reader = DataBase.dbDataTable(sql).CreateDataReader();
        //    reader.Read();
        //    for (int i = 0; i < reader.FieldCount; i++)
        //    {
        //        UserDetails.Add(reader.GetName(i), reader[i].ToString().Trim());

        //    }
        //    reader.Close();
        //}
        //catch { }



        return UserDetails;

    }
    public string fullname { get; set; }

    public string userphone { get; set; }

    public string useremail { get; set; }

    public string userofficecode { get; set; }

    public string userTitle { get; set; }

    public string userComponent { get; set; }

    public string Userfirstname { get; set; }

    public string Userlastname { get; set; }

    public string UserDomain { get; set; }

    public string UserServer { get; set; }
}